local function GetMPH(speed)
    return speed * 2.23694
end

local function GetSpeedLimitForVehicle(vehicle)
    local model = GetEntityModel(vehicle)
    return Config.SpeedLimits[model]
end

Citizen.CreateThread(function()
    while true do
        Wait(100)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            if GetPedInVehicleSeat(veh, -1) == ped then
                local limit = GetSpeedLimitForVehicle(veh)
                if limit then
                    local currentSpeed = GetMPH(GetEntitySpeed(veh))
                    if currentSpeed > limit then
                        -- Reduce speed by applying negative force
                        SetVehicleForwardSpeed(veh, limit / 2.23694)
                    end
                end
            end
        end
    end
end)
