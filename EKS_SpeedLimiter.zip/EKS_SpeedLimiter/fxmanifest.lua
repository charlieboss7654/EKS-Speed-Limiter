fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Vehicle Speed Restriction Script'
version '1.0.0'

client_script 'config.lua'
client_script 'client.lua'
