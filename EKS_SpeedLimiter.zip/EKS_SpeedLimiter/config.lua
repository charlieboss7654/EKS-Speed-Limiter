Config = {}

-- Vehicle model names and their max speeds (in mph)
Config.SpeedLimits = {
    [`adder`] = 80,
    [`sultan`] = 60,
    [`police`] = 90,
    [`t20`] = 70,
}
